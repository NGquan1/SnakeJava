package Screen;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.xml.crypto.Data;

public class Snake {
	int doDai = 3;
	int[] x;
	int[] y;
	long t = 0;
	boolean unChange = false;
	boolean save = false;
	public SoundPlayer eatApple, snakeOver, levelUp, BgMusic;
	SnakeRepo repo = new SnakeRepo();
	//ArrayList<User> list = new ArrayList<>();
	public static int GO_UP = 1;
	public static int GO_DOWN = -1;
	public static int GO_LEFT = 2;
	public static int GO_RIGHT = -2;

	int vector = Snake.GO_DOWN;

	int speed = 300;
	int LVMax = 10;

	public Snake() {
		x = new int[100];
		y = new int[100];
		x[0] = 5;
		y[0] = 4;
		x[1] = 5;
		y[1] = 3;
		x[2] = 5;
		y[2] = 2;
		eatApple= new SoundPlayer(new File("Sound/fap.wav"));
		snakeOver = new SoundPlayer(new File("Sound/fall.wav"));
		levelUp = new SoundPlayer(new File("Sound/getpoint.wav"));
		BgMusic = new SoundPlayer(new File("Sound/bg.wav"));
	}
	public void resetGame() {
		x = new int[100];
		y = new int[100];
		x[0] = 5;
		y[0] = 4;

		x[1] = 5;
		y[1] = 3;

		x[2] = 5;
		y[2] = 2;
		doDai=3;
		vector = GO_DOWN;



	}

	public void setVector(int v) {
		if (vector != -v && unChange)
			vector = v;
		unChange = false;
	}

	public Point viTriMoi() {
		Random r = new Random();
		int x, y;
		do {
			x = r.nextInt(19);
			y = r.nextInt(19);
		} while (kiemTraMoi(x, y));
		return new Point(x, y);
	}

	public boolean kiemTraMoi(int x1, int y1) {
		for (int i = 0; i < doDai; i++) {
			if (x[i] == x1 && y[i] == y1)
				return true;

		}
		return false;
	}
	public int getCurrentLevelSpeed() {
		for (int i = 0; i < GameScreen.currentLevel; i++) {
			speed *= 0.8;
		}
		return speed;
	}



	public void Update() {
		if(doDai == LVMax) {
			resetGame();
			GameScreen.currentLevel++;
			levelUp.play();
			LVMax+=5;
			speed  = getCurrentLevelSpeed();
		}

		for (int i = 1; i <doDai; i++) {
			if(x[0]==x[i] && y[0]==y[i]) {
				ArrayList<User> list ;
				String name = JOptionPane.showInputDialog("Moi Nhap Ten Player:");
				Frame.users2.add(new User2(name, String.valueOf(GameScreen.currentLevel), String.valueOf(GameScreen.gamePoint)));
				User user = new User(name, String.valueOf(GameScreen.currentLevel), String.valueOf(GameScreen.gamePoint));
				repo.add(user);
//				<User>) replist = (Arrayll();ListoetA.g
//			 	loadData(list);
			   GameScreen.isPlaying= false;
              	GameScreen.isGameOver = true;
				snakeOver.play();
				GameScreen.gamePoint =0;
				GameScreen.currentLevel =1;
				speed = 300;
				LVMax =10;
			}
		}

		if (System.currentTimeMillis() - t > speed) {
			unChange = true;
			DataSnake.headGoUp.update();
			DataSnake.headGoDown.update();
			DataSnake.headGoLeft.update();
			DataSnake.headGoRight.update();
			if (GameScreen.bg[x[0]][y[0]] == 2) {
				doDai++;
				GameScreen.gamePoint+= 10;
				eatApple.play();
				GameScreen.bg[x[0]][y[0]] = 0;
				GameScreen.bg[viTriMoi().x][viTriMoi().y] = 2;
			}

			for (int i = doDai - 1; i > 0; i--) {
				x[i] = x[i - 1];
				y[i] = y[i - 1];
			}
			if (vector == Snake.GO_UP) {
				y[0]--;
			}
			if (vector == Snake.GO_DOWN) {
				y[0]++;
			}
			if (vector == Snake.GO_RIGHT) {
				x[0]++;
			}
			if (vector == Snake.GO_LEFT) {
				x[0]--;
			}
			if (x[0] < 0) {
				x[0] = 19;
			}
			if (x[0] > 19) {
				x[0] = 0;
			}
			if (y[0] < 0) {
				y[0] = 19;
			}
			if (y[0] > 19) {
				y[0] = 0;
			}
			t = System.currentTimeMillis();
		}
	}

	public void Draw(Graphics g) {
		g.setColor(Color.red);
		for (int i = 1; i < doDai; i++) {
			g.drawImage(DataSnake.imagebody, x[i] * 20 + GameScreen.padding, y[i] * 20 + GameScreen.padding, null);

			if(vector == GO_UP)
				g.drawImage(DataSnake.headGoUp.getCurrentImage(), x[0]*20-6+ GameScreen.padding, y[0]*20-6+ GameScreen.padding, null);
			else if (vector == GO_LEFT)
				g.drawImage(DataSnake.headGoLeft.getCurrentImage(), x[0]*20-6+ GameScreen.padding, y[0]*20-6+ GameScreen.padding, null);
			else if (vector == GO_RIGHT)
				g.drawImage(DataSnake.headGoRight.getCurrentImage(), x[0]*20-6+ GameScreen.padding, y[0]*20-6+ GameScreen.padding, null);
			else if (vector == GO_DOWN)
				g.drawImage(DataSnake.headGoDown.getCurrentImage(), x[0]*20-6+ GameScreen.padding, y[0]*20-6+ GameScreen.padding, null);
		}

	}
	}

