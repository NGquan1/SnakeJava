package Screen;

import java.awt.Graphics;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import javax.imageio.ImageIO;

public class DataSnake {
	public static Image imagehead;
	public static Image imagebody;
	public static BufferedImage sprite;
	public static Image imagehead_goleft;
	public static Image imagehead_goright;
	public static Image imagehead_goup;
	public static Image imagehead_godown;
	public static Animation headGoUp;
	public static Animation headGoRight;
	public static Animation headGoLeft;
	public static Animation headGoDown;
	public static Animation WormAnimation;
	public static Image tao2;

	public static void loadImage() {
		try {
			tao2 = ImageIO.read(new File("Res/Apple.png"));
			sprite = ImageIO.read(new File("Res/sprite2k3.png"));
			imagehead = sprite.getSubimage(2, 3, 30, 30);
			imagebody = sprite.getSubimage(6, 79, 20, 20);
			imagehead_godown = sprite.getSubimage(39, 3, 30, 30);
			imagehead_goleft = sprite.getSubimage(75, 3, 30, 30);
			imagehead_goright = sprite.getSubimage(110, 3, 30, 30);
			imagehead_goup = sprite.getSubimage(145, 3, 30, 30);
			
            
		} catch (Exception e) {
		}
	}
	public static void loadAnimation() { 	
		 headGoUp = new Animation();
		 headGoUp.addImage(imagehead);
		 headGoUp.addImage(imagehead_goup);
		 
		 headGoDown = new Animation();
		 headGoDown.addImage(imagehead);
		 headGoDown.addImage(imagehead_godown);
		 
		 headGoLeft = new Animation();
		 headGoLeft.addImage(imagehead);
		 headGoLeft.addImage(imagehead_goleft);
		 
		 headGoRight = new Animation();
		 headGoRight.addImage(imagehead);
		 headGoRight.addImage(imagehead_goright);
	
	}
}
