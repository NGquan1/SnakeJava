package Screen;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFrame;
public class Frame extends JFrame {
	GameScreen gameScreen;
	SnakeRepo ran;
	public static ArrayList<User> users;
	public static ArrayList<User2> users2;
	

	public Frame() {
		users = new ArrayList<>();
		users2 = new ArrayList<>();
		gameScreen = new GameScreen();
		ran = new SnakeRepo();

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 458);
		add(gameScreen);
		this.addKeyListener(new KeyHandler());
		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
			    updateData();
			}

		});
		setVisible(true);
		setLocationRelativeTo(null);

	}

	public static void main(String args[]) {
		Frame f = new Frame();
		f.ran.getAll();
		f.readData();

	}

	private class KeyHandler implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {

		}

		@Override
		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_SPACE) {
				GameScreen.isPlaying = !gameScreen.isPlaying;
				if (!gameScreen.isPlaying) {
					gameScreen.s.BgMusic.stop();
				}
				if (gameScreen.isGameOver) {
					gameScreen.isGameOver = false;
					gameScreen.s.resetGame();
				}
			}
			
//			if(e.getKeyCode() == KeyEvent.VK_R) {
//				
//					gameScreen.s.daoNguoc();
//				
//			}
			

			if (e.getKeyCode() == KeyEvent.VK_UP) {
				gameScreen.s.setVector(Snake.GO_UP);
			}
			if (e.getKeyCode() == KeyEvent.VK_DOWN) {
				gameScreen.s.setVector(Snake.GO_DOWN);
			}
			if (e.getKeyCode() == KeyEvent.VK_LEFT) {
				gameScreen.s.setVector(Snake.GO_LEFT);
			}
			if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
				gameScreen.s.setVector(Snake.GO_RIGHT);
			}

			}

		@Override
		public void keyReleased(KeyEvent e) {
		}

	}


	public void updateData() {
		BufferedWriter bw = null;
		try {
			FileWriter fw = new FileWriter("Data/data.txt");
			bw = new BufferedWriter(fw);
            for(User2 u : users2) {
            	 bw.write(u.getName2()+" "+u.getLevel2()+" "+u.getScores2());
            	 bw.newLine();
            }

			bw.close();
		} catch (IOException e) {}
		finally {
			try {
				bw.close();
			} catch (Exception e2) {}
		}
	}
	public void readData() {
		try {
			FileReader fr= new FileReader("Data/data.txt");
			BufferedReader br= new BufferedReader(fr);
			String line = null;
			while((line= br.readLine())!= null) {
				String[] str = line.split(" ");
				users2.add(new User2(str[0], str[1], str[2]));
				
			}
			br.close();
		} catch (IOException e) {
			
		}
	}
	}

