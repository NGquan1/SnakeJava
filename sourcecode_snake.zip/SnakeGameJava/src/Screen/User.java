package Screen;

public class User {
      private String name;
      private String level;
      private String scores;

	public User() {
	}

	public User(String name, String level, String scores) {
		this.name = name;
		this.level = level;
		this.scores = scores;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getScores() {
		return scores;
	}

	public void setScores(String scores) {
		this.scores = scores;
	}

	@Override
	public String toString() {
		return  "Name:"+name +" "+"LV:"+ level+" "+"Diem:" + scores;
	}
}
