package Screen;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SnakeRepo {
    public List<User> getAll() {
        String query = "Select *from snakeUser";//nhap ten bang vua tao trong lop sqlConnection
        try (Connection con = sqlConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query);) {
            ResultSet rs = ps.executeQuery();
            List<User> listkh = new ArrayList<>();
            while (rs.next()) {
                User kh = new User(rs.getString(1), rs.getString(2), rs.getString(3));
                listkh.add(kh);
            }
            return listkh;

        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public boolean add(User kh) {
        String query = "insert into snakeUser(ten,level,diem) values (?,?,?)";//nhap du lieu vao table vua tao trong database
        int check = 0;
        try (Connection con = sqlConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, kh.getName());
            ps.setObject(2, kh.getLevel());
            ps.setObject(3, kh.getScores());
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public static void main(String[] args) {
        System.out.println(new SnakeRepo().getAll());
    }
}
