package Screen;

public class User2 {
	private String name2;
    private String level2;
    private String scores2;

	public User2() {
	}

	public User2(String name, String level, String scores) {
		this.name2 = name;
		this.level2 = level;
		this.scores2 = scores;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name) {
		this.name2 = name;
	}

	public String getLevel2() {
		return level2;
	}

	public void setLevel2(String level) {
		this.level2 = level;
	}

	public String getScores2() {
		return scores2;
	}

	public void setScores2(String scores) {
		this.scores2 = scores;
	}

	@Override
	public String toString() {
		return  "Name:"+name2 +" "+"LV:"+ level2+" "+"Diem:" + scores2;
	}
}

