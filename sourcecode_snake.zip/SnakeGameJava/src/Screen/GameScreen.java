package Screen;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.xml.crypto.Data;

public class GameScreen extends JPanel implements Runnable {
	SnakeRepo repo = new SnakeRepo();
	ArrayList<User> list = (ArrayList<User>) repo.getAll();
	
	static int[][] bg = new int[20][20];
	Thread thread;
	Snake s;
	static int padding = 10;
	static int WIDTH = 400;
	static int HEIGHT = 400;
	static boolean isPlaying = false;
	static boolean textStartGame = true;
	static boolean isGameOver = false;
	static int currentLevel = 1;
	static int gamePoint = 0;
	static boolean pause = false;

	public GameScreen() {
		s = new Snake();
		DataSnake.loadImage();
		DataSnake.loadAnimation();
		bg[10][7] = 2;
		thread = new Thread(this);
		thread.start();
	}

	public void PaintBg(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH + padding * 2 + 370, HEIGHT + padding * 2);
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 20; j++) {
				if (bg[i][j] == 2) {
					s.viTriMoi();
					g.drawImage(DataSnake.tao2, i * 20 - 6 + padding, j * 20 - 6 + padding, null);
				}
			}

		}
	}

	public void Vien(Graphics g) {
		g.setColor(Color.white);
		g.drawRect(0, 0, WIDTH + padding * 2, HEIGHT + padding * 2);
		g.drawRect(1, 1, WIDTH + padding * 2 - 2, HEIGHT + padding * 2 - 2);
		g.drawRect(2, 2, WIDTH + padding * 2 - 4, HEIGHT + padding * 2 - 4);

		g.drawRect(0, 0, WIDTH + padding * 2 + 366, HEIGHT + padding * 2);
		g.drawRect(1, 1, WIDTH + padding * 2 - 2 + 366, HEIGHT + padding * 2 - 2);
		g.drawRect(2, 2, WIDTH + padding * 2 - 4 + 366, HEIGHT + padding * 2 - 4);
	}

	public void run() {
		long t = 0;
		long t1 = 0;
		while (true) {

			if (System.currentTimeMillis() - t1 > 500) {
				textStartGame = !textStartGame;
				t1 = System.currentTimeMillis();
			}

			if (isPlaying) {
				s.Update();
				s.BgMusic.loop();
			}
			repaint();
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
			}

		}
	}

	public void paint(Graphics g) {
		PaintBg(g);
		s.Draw(g);
		Vien(g);
		if (!isPlaying) {
			if (textStartGame) {
				g.setColor(Color.yellow);
				g.setFont(getFont().deriveFont(20.0f));
				g.drawString("Press Space To Start Game!", 80, 230);
			}

		}
		if (pause) {
			g.setColor(Color.yellow);
			g.setFont(getFont().deriveFont(20.0f));
			g.drawString("Press Enter To Continue Game!", 80, 230);

		}

		if (isGameOver) {
			g.setColor(Color.yellow);
			g.setFont(getFont().deriveFont(40.0f));
			g.drawString("Game Over!", 100, 200);
		}
		g.setColor(Color.yellow);
		g.setFont(getFont().deriveFont(28.0f));
		g.drawString("LEVEL " + currentLevel, 450, 40);
		g.setColor(Color.yellow);
		g.setFont(getFont().deriveFont(24.0f));
		g.drawString("SCORES: " + gamePoint, 450, 80);

		g.setColor(Color.yellow);
		g.setFont(getFont().deriveFont(20.0f));
		g.drawString("PLAYER LIST", 540, 120);

		for (int i = 0; i < Frame.users2.size(); i++) {
			g.setColor(Color.yellow);
			g.setFont(getFont().deriveFont(20.0f));
			g.drawString(Frame.users2.get(i).toString(), 450, i * 30 + 150);

		}

	}
}